select *

from top_10produzenten
where Produktion_Mio_Tonnen < 50;