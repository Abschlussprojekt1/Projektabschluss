select 
avg(produktion_Mio_Tonnen) Durchschnittsproduktion

from top_10produzenten;