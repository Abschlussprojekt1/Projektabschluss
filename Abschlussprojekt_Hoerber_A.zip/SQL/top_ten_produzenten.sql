select *

from top_10produzenten

order by Produktion_Mio_Tonnen desc;