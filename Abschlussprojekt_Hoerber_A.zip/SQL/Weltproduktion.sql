select
jahr, produktion_Mio_Tonnen
from weltproduktion
order by jahr;

