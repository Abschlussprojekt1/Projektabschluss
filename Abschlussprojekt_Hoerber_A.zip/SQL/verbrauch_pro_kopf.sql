select *
from verbauch_pro_kopf
order by Verbrauch_pro_kopf desc;