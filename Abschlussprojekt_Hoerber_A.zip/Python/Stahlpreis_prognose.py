import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# 📁 CSV laden (Spalten: Jahr, Preis)
df = pd.read_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\stahlpreis.csv")  # Beispiel-Datei
df = df.dropna()

# 🔧 Features & Ziel definieren
X = df[["Jahr"]]
y = df["Stahlpreis_USD_CO2"]

# 🧠 Lineares Modell trainieren
model = LinearRegression().fit(X, y)

# 🔮 Prognosejahre (2024–2035)
years_future = pd.DataFrame({"Jahr": range(2024, 2036)})
preds = model.predict(years_future)

# 🧾 Prognose speichern
prognose_df = years_future.copy()
prognose_df["Stahlpreis_Prognose_USD"] = preds
prognose_df.to_csv("stahlpreis_prognose_2024_2035.csv", index=False, sep=";", float_format="%.2f")
print("✅ Prognose gespeichert in stahlpreis_prognose_2024_2035.csv")

# 📈 Visualisierung
plt.figure(figsize=(10, 6))
plt.scatter(X, y, label="Historisch", color="black")
plt.plot(X, model.predict(X), label="Trendlinie", color="blue")
plt.plot(years_future, preds, "--", label="Prognose 2024–2035", color="red")
plt.xlabel("Jahr")
plt.ylabel("Stahlpreis (USD/t)")
plt.title("📈 Stahlpreis-Prognose bis 2035")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
