# 📦 Pakete importieren
import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt

# 📁 Daten laden
df = pd.read_csv("C:/Users/User/Documents/Abschlussprojekt/Erzeugung/gesamtproduktion.csv")

# 📆 Prophet benötigt 'ds' (Datum) und 'y' (Ziel)
df_prophet = df.rename(columns={"Jahr": "ds", "Produktion_Mio_Tonnen": "y"})
df_prophet["ds"] = pd.to_datetime(df_prophet["ds"], format="%Y")

# 📈 Prophet-Modell trainieren
model = Prophet(yearly_seasonality=False, daily_seasonality=False, weekly_seasonality=False)
model.fit(df_prophet)

# 🔮 Zukunftsdaten bis 2035 erzeugen
future = model.make_future_dataframe(periods=12, freq="Y")
forecast = model.predict(future)

# 📊 Plot anzeigen
fig1 = model.plot(forecast)
plt.title("Prognose der Stahlproduktion weltweit (Prophet)")
plt.xlabel("Jahr")
plt.ylabel("Produktion (Mio. Tonnen)")
plt.grid(True)
plt.show()

# 📄 Prognose extrahieren und speichern
prognose_df = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
prognose_df.columns = ["Jahr", "Prognose", "Prognose_Min", "Prognose_Max"]
prognose_df["Jahr"] = prognose_df["Jahr"].dt.year

# Nur Prognose ab 2024
prognose_2024plus = prognose_df[prognose_df["Jahr"] >= 2024]
prognose_2024plus.to_csv("prognose_stahlproduktion_prophet_2024-2035.csv",
                          index=False, sep=";", encoding="utf-8-sig", float_format="%.2f")

print("→ Prognose-Datei gespeichert: prognose_stahlproduktion_prophet_2024-2035.csv")
