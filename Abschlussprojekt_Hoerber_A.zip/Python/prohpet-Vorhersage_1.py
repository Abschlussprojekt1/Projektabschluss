from prophet import Prophet
import pandas as pd
import matplotlib.pyplot as plt

# CSV einlesen
df = pd.read_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\prod90_23.csv")

# Prophet-kompatiblen DataFrame erstellen
df_prophet = df.rename(columns={
    'Jahr': 'ds',
    'CO2_pro_t': 'y'
})
df_prophet['ds'] = pd.to_datetime(df_prophet['ds'], format='%Y')

# Modell initialisieren und trainieren
model = Prophet()
model.fit(df_prophet)

# Zukunftsdaten generieren (10 Jahre)
future = model.make_future_dataframe(periods=10, freq='Y')

# Prognose berechnen
forecast = model.predict(future)

# Nur relevante Spalten für Export
forecast_export = forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']]

# CSV speichern
forecast_export.to_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\CO2_Prognose.csv", index=False)
print("✅ Prognose gespeichert als 'CO2_Prognose.csv'.")

# Diagramm anzeigen
fig1 = model.plot(forecast)
plt.title("Prognose: CO₂-Ausstoß pro Tonne Stahl")
plt.xlabel("Jahr")
plt.ylabel("CO₂ pro t")
plt.grid(True)
plt.show()

# Komponenten anzeigen
fig2 = model.plot_components(forecast)
plt.show()
