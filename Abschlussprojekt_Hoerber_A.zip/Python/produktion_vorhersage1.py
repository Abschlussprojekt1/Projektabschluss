# 📦 Pakete importieren
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_absolute_error, mean_squared_error
import numpy as np

# 📁 Daten laden
df = pd.read_csv("C:/Users/User/Documents/Abschlussprojekt/Erzeugung/gesamtproduktion.csv")

# 🎯 Features und Ziel definieren
X = df["Jahr"].values.reshape(-1, 1)
y = df["Produktion_Mio_Tonnen"].values

# 🔀 Daten aufteilen
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# 🧠 Modell 1: Lineare Regression
lr_model = LinearRegression()
lr_model.fit(X_train, y_train)
y_pred_lr = lr_model.predict(X_test)

# 🧠 Modell 2: Random Forest Regression
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)
y_pred_rf = rf_model.predict(X_test)

# 📊 Fehlervergleich
def print_errors(name, y_test, y_pred):
    mae = mean_absolute_error(y_test, y_pred)
    mse = mean_squared_error(y_test, y_pred)
    rmse = np.sqrt(mse)
    print(f"🔍 {name} Fehler:")
    print(f"  MAE : {mae:.2f}")
    print(f"  MSE : {mse:.2f}")
    print(f"  RMSE: {rmse:.2f}\n")

print("📉 Testdaten-Fehlervergleich:")
print_errors("Lineare Regression", y_test, y_pred_lr)
print_errors("Random Forest", y_test, y_pred_rf)

# 🔮 Prognose auf zukünftige Jahre (2024–2035)
future_years = np.arange(2024, 2036).reshape(-1, 1)
future_pred_lr = lr_model.predict(future_years)
future_pred_rf = rf_model.predict(future_years)

# 📈 Visualisierung
plt.figure(figsize=(12, 6))
plt.scatter(X_train, y_train, color="blue", label="Trainingsdaten")
plt.scatter(X_test, y_test, color="green", label="Testdaten")
plt.plot(X, lr_model.predict(X), color="black", label="Linear Fit")
plt.plot(future_years, future_pred_lr, color="red", linestyle="--", label="Prognose Linear")
plt.plot(future_years, future_pred_rf, color="orange", linestyle="--", label="Prognose Random Forest")
plt.xlabel("Jahr")
plt.ylabel("Produktion (Mio. Tonnen)")
plt.title("Modellvergleich: Lineare Regression vs. Random Forest")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# 📄 Prognose in DataFrame packen und speichern
prognose_df = pd.DataFrame({
    "Jahr": future_years.flatten(),
    "Prognose_Linear_Mio_Tonnen": future_pred_lr,
    "Prognose_RF_Mio_Tonnen": future_pred_rf
})

prognose_df.to_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\prognose_stahlproduktion_2024-2035.csv",
                   index=False, sep=";", encoding="utf-8-sig", float_format="%.2f")
print("→ Datei prognose_stahlproduktion_2024-2035.csv gespeichert.")
