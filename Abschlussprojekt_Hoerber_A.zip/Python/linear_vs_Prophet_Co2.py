import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from prophet import Prophet
import numpy as np

# 📁 Daten laden
df = pd.read_csv("C:/Users/User/Documents/Abschlussprojekt/Erzeugung/gesamtproduktion.csv")

# 🔧 Prophet vorbereiten
df_prophet = df.rename(columns={"Jahr": "ds", "Produktion_Mio_Tonnen": "y"})
df_prophet["ds"] = pd.to_datetime(df_prophet["ds"], format="%Y")

model_prophet = Prophet(yearly_seasonality=False)
model_prophet.fit(df_prophet)

# 🕒 Prophet-Vorhersage vorbereiten (1. Januar jedes Jahres statt 31.12.)
future = pd.date_range(start="2024-01-01", end="2035-01-01", freq="YS")  # YS = Year Start
future_df = pd.DataFrame({"ds": future})
forecast = model_prophet.predict(future_df)

# 🔧 Lineares Modell vorbereiten
X = df["Jahr"].values.reshape(-1, 1)
y = df["Produktion_Mio_Tonnen"].values
model_linear = LinearRegression().fit(X, y)

# Prognosejahre 2024–2035
years_future = np.arange(2024, 2036).reshape(-1, 1)
pred_linear = model_linear.predict(years_future)

# ✂️ Prophet-Ergebnisse extrahieren und Jahr hinzufügen
forecast["Jahr"] = forecast["ds"].dt.year
forecast_2024plus = forecast[["Jahr", "yhat", "yhat_lower", "yhat_upper"]].copy()

# 🧾 Historische Daten vorbereiten
historisch_df = df[["Jahr", "Produktion_Mio_Tonnen"]].copy()
historisch_df.rename(columns={"Produktion_Mio_Tonnen": "Historische_Daten"}, inplace=True)

# 🔮 Prognosen als DataFrame
prognose_df = pd.DataFrame({
    "Jahr": years_future.flatten(),
    "Lineare_Prognose": pred_linear,
    "Prophet_Prognose": forecast_2024plus["yhat"].values,
    "Prophet_Min": forecast_2024plus["yhat_lower"].values,
    "Prophet_Max": forecast_2024plus["yhat_upper"].values
})

# 🔗 Historische und Prognose-Daten zusammenführen
gesamt_df = pd.merge(historisch_df, prognose_df, on="Jahr", how="outer").sort_values("Jahr")

# 💾 Speichern
gesamt_df.to_csv("C:/Users/User/Documents/Abschlussprojekt/Erzeugung/gesamt_mit_prognose_1990-2035.csv",
                 index=False, sep=";", encoding="utf-8-sig", float_format="%.2f")

print("✅ Datei mit historischen Daten und Prognosen gespeichert.")


# 📊 Visualisierung
plt.figure(figsize=(12, 6))

# Historische Daten
plt.scatter(df["Jahr"], df["Produktion_Mio_Tonnen"], color="black", label="Historische Daten")

# Lineare Prognose
plt.plot(df["Jahr"], model_linear.predict(X), color="blue", label="Lineare Regression (Trend)")
plt.plot(years_future, pred_linear, "--", color="blue", label="Lineare Prognose 2024–2035")

# Prophet Prognose
plt.plot(forecast_2024plus["Jahr"], forecast_2024plus["yhat"], color="red", label="Prophet Prognose")
plt.fill_between(forecast_2024plus["Jahr"], forecast_2024plus["yhat_lower"], forecast_2024plus["yhat_upper"],
                 color="red", alpha=0.2, label="Prophet Unsicherheitsbereich")

# Styling
plt.xlabel("Jahr")
plt.ylabel("Produktion (Mio. Tonnen)")
plt.title("📈 Vergleich: Lineare Regression vs. Prophet")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()
