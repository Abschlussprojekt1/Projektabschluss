# Installation (falls nötig)
# !pip install prophet

import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt

# CSV laden
df = pd.read_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\prod90_23.csv")

# Prophet-Format: Zielspalte = 'y', Zeitspalte = 'ds'
df_prophet = df.rename(columns={
    'Jahr': 'ds',
    'CO2_pro_t': 'y'
})

# Zeit in datetime umwandeln
df_prophet['ds'] = pd.to_datetime(df_prophet['ds'], format='%Y')

# Externe Regressoren definieren
regressors = ['Strompreis', 'Eisenschrott_Quote', 'CO2_Preis']

# Prophet-Modell mit Regressoren vorbereiten
model = Prophet()

# Regressoren hinzufügen
for reg in regressors:
    model.add_regressor(reg)

# Modell trainieren
model.fit(df_prophet[['ds', 'y'] + regressors])

# Zukünftigen DataFrame erzeugen (10 Jahre)
future = model.make_future_dataframe(periods=10, freq='Y')

# Für die Zukunft Dummy-Werte definieren (z. B. lineare Fortsetzung oder Konstanten)
# Hier: Einfach letzte bekannte Werte verwenden (für einfache Demo)
for reg in regressors:
    last_value = df_prophet[reg].iloc[-1]
    future[reg] = list(df_prophet[reg]) + [last_value]*10

# Prognose erstellen
forecast = model.predict(future)

# Plot
fig1 = model.plot(forecast)
plt.title("Vorhersage CO₂-Ausstoß mit Regressoren")
plt.xlabel("Jahr")
plt.ylabel("CO₂ pro t Stahl")

# Komponentenplot
fig2 = model.plot_components(forecast)
