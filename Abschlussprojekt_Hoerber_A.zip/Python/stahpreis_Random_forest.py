import pandas as pd
from sklearn.model_selection import train_test_split
#from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.datasets import make_regression
import matplotlib.pyplot as plt

# 🔹 1. Daten laden
df = pd.read_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\prod90_23.csv")
df = df.dropna()  # Fehlende Werte entfernen

# 🔹 2. Features und Ziel definieren
X = df[["CO2_Preis", "Strompreis", "Eisenschrott_Quote", "Produktion_Mio_t"]]
y = df["Stahlpreis"]
#X, y = make_regression(n_samples=100, n_features=4, noise=0.1, random_state=42)
#X = df[["CO2_Preis", "Strompreis", "Eisenschrott_Quote", "Produktion_Mio_t"]]
#y = df["Stahlpreis"]

# 🔹 3. Trainings- und Testdaten aufteilen
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# 🔹 4. Modell trainieren
model = XGBRegressor()
model.fit(X_train, y_train)

# 🔹 5. Vorhersage und Bewertung
y_pred = model.predict(X_test)
mae = mean_absolute_error(y_test, y_pred)
r2 = r2_score(y_test, y_pred)

print(f"MAE: {mae:.2f}")
print(f"R²: {r2:.2f}")

# 🔹 6. Visualisierung
plt.figure(figsize=(10, 4))
plt.plot(y_test, label="Echte Preise")
plt.plot(y_pred, label="Vorhersage")
plt.title("Stahlpreis-Vorhersage mit Random Forest")
plt.legend()
plt.show()

# 🔹 7. Wichtigste Einflussfaktoren anzeigen
importances = model.feature_importances_
for name, importance in zip(X.columns, importances):
    print(f"{name}: {importance:.2f}")
