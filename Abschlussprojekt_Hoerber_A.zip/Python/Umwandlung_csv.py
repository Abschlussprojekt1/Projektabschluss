import pandas as pd

# 📁 Ursprüngliche Datei laden
df = pd.read_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\für Tableau\\gesamt_mit_prognose_1990-2035.csv", sep=";", encoding="utf-8-sig")

# 🧼 DataFrame ins lange Format umwandeln
df_long = pd.melt(
    df,
    id_vars=["Jahr"],
    value_vars=["Historische_Daten", "Lineare_Prognose", "Prophet_Prognose"],
    var_name="Typ",
    value_name="Produktion_Mio_Tonnen"
)

# 🔢 Prophet-Unsicherheitsbereich optional dazufügen
df_uncertainty = df[["Jahr", "Prophet_Min", "Prophet_Max"]].copy()
df_uncertainty = df_uncertainty[df_uncertainty["Prophet_Min"].notna()]  # Nur gültige Zeilen
df_uncertainty["Typ"] = "Prophet_Unsicherheitsbereich"

# Merge: Prophet-Mitte + Min + Max
df_uncertainty = df_uncertainty.rename(columns={
    "Prophet_Min": "Produktion_Min",
    "Prophet_Max": "Produktion_Max"
})

# 💾 Speichern in neuer CSV
df_long.to_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\für Tableau\\gesamt_mit_prognose_long.csv", index=False, sep=";", encoding="utf-8-sig")
df_uncertainty.to_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\für Tableau\\prophet_unsicherheitsbereich.csv", index=False, sep=";", encoding="utf-8-sig")

print("✅ Gespeichert als 'gesamt_mit_prognose_long.csv' und 'prophet_unsicherheitsbereich.csv'")
