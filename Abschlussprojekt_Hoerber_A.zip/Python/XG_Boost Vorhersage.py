
import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error
import numpy as np



# CSV laden
df = pd.read_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\prod90_23.csv")

# Merkmale und Ziel definieren
features = ['Produktion_Mio_t', 'Strompreis', 'Eisenschrott_Quote', 'CO2_Preis']
target = 'CO2_pro_t'

X = df[features]
y = df[target]

# Daten aufteilen (z. B. 80/20)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, shuffle=False)



# XGBoost Regressor trainieren
model = xgb.XGBRegressor(n_estimators=100, learning_rate=0.1)
model.fit(X_train, y_train)

# Vorhersage
y_pred = model.predict(X_test)

# Bewertung
#rmse = mean_squared_error(y_test, y_pred, squared=False)
r2 = r2_score(y_test, y_pred)

mse = mean_squared_error(y_test, y_pred)
rmse = np.sqrt(mse)

print(f"RMSE: {rmse:.2f}")
print(f"R²: {r2:.2f}")

# Vergleich: Echte vs. Vorhergesagte Werte
plt.plot(y_test.values, label='Echte Werte')
plt.plot(y_pred, label='Vorhersage')
plt.legend()
plt.title("XGBoost-Vorhersage CO₂ pro t")
plt.xlabel("Index")
plt.ylabel("CO₂ pro t")
plt.grid(True)
plt.show()

# Feature-Wichtigkeit
xgb.plot_importance(model)
plt.title("Feature-Wichtigkeit")
plt.show()
