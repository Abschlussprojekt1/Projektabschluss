import pandas as pd
from prophet import Prophet
import matplotlib.pyplot as plt

# 📄 CSV laden
df = pd.read_csv("C:\\Users\\User\\Documents\\Abschlussprojekt\\Erzeugung\\stahlpreis.csv")

# 📆 Prophet vorbereiten
df = df.rename(columns={"Jahr": "ds", "Stahlpreis_USD_CO2": "y"})
df["ds"] = pd.to_datetime(df["ds"], format="%Y")

# 📈 Prophet-Modell
model = Prophet(yearly_seasonality=False)
model.fit(df)

# 🔮 Zukunft bis 2035
future = model.make_future_dataframe(periods=12, freq="Y")
forecast = model.predict(future)

# 🧾 Kombination aus historisch + Prognose
combined_df = forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].copy()
combined_df = combined_df.rename(columns={
    "ds": "Jahr", "yhat": "Prognose_Stahlpreis_USD",
    "yhat_lower": "Prognose_Min", "yhat_upper": "Prognose_Max"
})
combined_df["Jahr"] = combined_df["Jahr"].dt.year

# 📊 Plot
plt.figure(figsize=(12, 6))
plt.plot(df["ds"], df["y"], label="Historische Stahlpreise", color="black")
plt.plot(forecast["ds"], forecast["yhat"], label="Prognose", color="blue")
plt.fill_between(forecast["ds"], forecast["yhat_lower"], forecast["yhat_upper"],
                 color="blue", alpha=0.2, label="Unsicherheitsbereich")
plt.title("📈 Stahlpreis-Prognose bis 2035 (Prophet)")
plt.xlabel("Jahr")
plt.ylabel("Stahlpreis (USD/t)")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

# 💾 Export als CSV
combined_df.to_csv("stahlpreis_prognose_2010-2035.csv", index=False, sep=";", encoding="utf-8-sig")
print("✅ CSV-Datei gespeichert: stahlpreis_prognose_2010-2035.csv")
