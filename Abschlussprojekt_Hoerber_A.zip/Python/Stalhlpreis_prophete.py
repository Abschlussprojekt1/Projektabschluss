from prophet import Prophet
import pandas as pd
import matplotlib.pyplot as plt

# CSV einlesen
df = pd.read_csv("C:/Users/User/Documents/Abschlussprojekt/Erzeugung/stahlpreis.csv")

# Prophet-Format: Spalten umbenennen
df = df.rename(columns={"Jahr": "ds", "Stahlpreis_USD_CO2": "y"})
df["ds"] = pd.to_datetime(df["ds"], format="%Y")

# Modell erstellen und trainieren
model = Prophet()
model.fit(df)

# Prognose für 12 Jahre
future = model.make_future_dataframe(periods=12, freq="Y")
forecast = model.predict(future)

# Ausgabe
forecast[["ds", "yhat", "yhat_lower", "yhat_upper"]].tail(12).to_csv(
    "C:/Users/User/Documents/Abschlussprojekt/Erzeugung/stahlpreis_prognose_2024-2035.csv",
    index=False, sep=";", encoding="utf-8-sig", float_format="%.2f"
)

# Visualisierung (optional)
fig1 = model.plot(forecast)
plt.show()

